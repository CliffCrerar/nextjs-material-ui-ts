import Editor from './Layout';

export default Editor;
